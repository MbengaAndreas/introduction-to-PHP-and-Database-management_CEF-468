<!DOCTYPE html>
<html>
<head><title>Add Author</title></head>
<body>
<h2>Add Author</h2>
<form method="POST" action="insert_author.php">
    Name: <input type="text" name="name" required><br><br>
    Email: <input type="email" name="email"><br><br>
    <input type="submit" value="Add Author">
</form>
<br>
<a href="add_book.php">Add Book</a> | <a href="display_books.php">View All Books</a>
</body>
</html>

