<!DOCTYPE html>
<html>
<head><title>User Registration</title></head>
<body>
<h2>Register User</h2>
<form method="POST" action="insert.php">
    Name: <input type="text" name="name" required><br><br>
    Email: <input type="email" name="email" required><br><br>
    Age: <input type="number" name="age" required><br><br>
    <input type="submit" value="Submit">
</form>
<br>
<a href="users.php">View All Users</a>
</body>
</html>




