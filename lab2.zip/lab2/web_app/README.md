1. Open phpMyAdmin.
2. Create a new database named WebAppDB.
3. Click 'Import' and choose WebAppDB.sql from the project folder.
4. Click 'Go' to import.
5. Now you can run the app from http://localhost/web_app/register.php

