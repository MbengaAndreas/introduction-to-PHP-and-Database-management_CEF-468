<!DOCTYPE html>
<html>
<head><title>Add Department</title></head>
<body>
<h2>Add Department</h2>
<form method="POST" action="insert_department.php">
    Department Name: <input type="text" name="dept_name" required><br><br>
    Location: <input type="text" name="dept_location" required><br><br>
    <input type="submit" value="Add Department">
</form>
</body>
</html>
