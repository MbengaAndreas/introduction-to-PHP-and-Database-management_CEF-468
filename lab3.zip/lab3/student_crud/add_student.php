<!DOCTYPE html>
<html>
<head><title>Add Student</title></head>
<body>
    <h2>Add New Student</h2>
    <form method="post" action="insert_student.php">
        Name: <input type="text" name="name" required><br><br>
        Email: <input type="email" name="email" required><br><br>
        Phone Number: <input type="text" name="phone_number" required><br><br>
        <input type="submit" value="Add Student">
    </form>
</body>
</html>
